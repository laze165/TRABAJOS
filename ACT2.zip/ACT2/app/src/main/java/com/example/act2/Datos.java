package com.example.act2;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;
import java.util.Calendar;

public class Datos extends AppCompatActivity {

    private TextInputEditText TextNombre, TextTelefono, TextEmail, TextDescripcion;
    private Button BotonSiguiente, BotonFechaNacimiento;
    private TextView SFFechaSeleccionada;
    private Calendar CALENDARIO;
    private int year, month, day;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rellenardatos);

        TextNombre = findViewById(R.id.IDNOMBRE);
        TextTelefono = findViewById(R.id.IDTELEFONO);
        TextEmail = findViewById(R.id.IDCORREO);
        TextDescripcion = findViewById(R.id.IDDESCRIPCION);
        BotonSiguiente = findViewById(R.id.BOTONSig);
        BotonFechaNacimiento = findViewById(R.id.BOTONFecha);
        SFFechaSeleccionada = findViewById(R.id.SRFechaSeleccionada);
        BotonFechaNacimiento.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(Datos.this,
                        (view, year, monthOfYear, dayOfMonth) -> {
                            // Mostrar la fecha seleccionada en el TextView
                            SFFechaSeleccionada.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                        }, year, month, day);
                datePickerDialog.show();
            }
        });

        CALENDARIO = Calendar.getInstance();
        year = CALENDARIO.get(Calendar.YEAR);
        month = CALENDARIO.get(Calendar.MONTH);
        day = CALENDARIO.get(Calendar.DAY_OF_MONTH);
        Intent intent = getIntent();
        String nombre = intent.getStringExtra("nombre");
        String telefono = intent.getStringExtra("telefono");
        String email = intent.getStringExtra("email");
        String descripcion = intent.getStringExtra("descripcion");
        String fechaNacimiento = intent.getStringExtra("fechaNacimiento");

        if (nombre != null) {
            TextNombre.setText(nombre);
        }
        if (telefono != null) {
            TextTelefono.setText(telefono);
        }
        if (email != null) {
            TextEmail.setText(email);
        }
        if (descripcion != null) {
            TextDescripcion.setText(descripcion);
        }
        if (fechaNacimiento != null) {
            SFFechaSeleccionada.setText(fechaNacimiento);
        }


        BotonSiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre = TextNombre.getText().toString();
                String telefono = TextTelefono.getText().toString();
                String email = TextEmail.getText().toString();
                String descripcion = TextDescripcion.getText().toString();
                String fechaNacimiento = SFFechaSeleccionada.getText().toString();
                if (nombre.isEmpty() || telefono.isEmpty() || email.isEmpty() || descripcion.isEmpty() || fechaNacimiento.isEmpty()) {
                    Toast.makeText(Datos.this, "completar todos los datos solicitados", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(Datos.this, DevolDatos.class);
                    intent.putExtra("nombre", nombre);
                    intent.putExtra("telefono", telefono);
                    intent.putExtra("email", email);
                    intent.putExtra("descripcion", descripcion);
                    intent.putExtra("fechaNacimiento", fechaNacimiento);
                    startActivity(intent);
                }
            }
        });
    }
}