package com.example.act2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DevolDatos extends AppCompatActivity {
    private TextView CFNombre, CFTelefono, CFEmail, CFDescripcion, CFFechaNacimiento;
    private Button BOTONEDIT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.devolverdatos);
        String nombre = getIntent().getStringExtra("nombre");
        String telefono = getIntent().getStringExtra("telefono");
        String email = getIntent().getStringExtra("email");
        String descripcion = getIntent().getStringExtra("descripcion");
        String fechaNacimiento = getIntent().getStringExtra("fechaNacimiento");
        CFNombre = findViewById(R.id.VRNombre);
        CFTelefono = findViewById(R.id.VRTelefono);
        CFEmail = findViewById(R.id.VRCorreo);
        CFDescripcion = findViewById(R.id.VRDescripcion);
        CFFechaNacimiento = findViewById(R.id.VRFechaNacimiento);
        BOTONEDIT = findViewById(R.id.BotonEditar);
        CFNombre.setText("Nombre Completo: " + nombre);
        CFTelefono.setText("Teléfono: " + telefono);
        CFEmail.setText("Email: " + email);
        CFDescripcion.setText("Descripción: " + descripcion);
        CFFechaNacimiento.setText("Fecha de Nacimiento: " + fechaNacimiento);


        BOTONEDIT.setOnClickListener(v -> {
            Intent intent = new Intent(DevolDatos.this, Datos.class);
            intent.putExtra("nombre", CFNombre.getText().toString().replace("Nombre Completo: ", ""));
            intent.putExtra("telefono", CFTelefono.getText().toString().replace("Teléfono: ", ""));
            intent.putExtra("email", CFEmail.getText().toString().replace("Email: ", ""));
            intent.putExtra("descripcion", CFDescripcion.getText().toString().replace("Descripción: ", ""));
            intent.putExtra("fechaNacimiento", CFFechaNacimiento.getText().toString().replace("Fecha de Nacimiento: ", ""));
            startActivity(intent);
        });
    }
}


